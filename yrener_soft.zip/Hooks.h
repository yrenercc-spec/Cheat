#ifndef HOOKS_H
#define HOOKS_H

#include <stdint.h>
#include <vector>
#include <time.h>
#include "imgui/imgui.h"

// ── OFFSETS (libblackrussia-client.so v16.65.13320) ──────────────
#define ADDR_FOV            0x00298d94
#define ADDR_BULLET_IMPACT  0x002e6d07
#define ADDR_HIT_EVENT      0x002ffbbd
#define ADDR_FLY_SPEED      0x002c5153

// ── SETTINGS ─────────────────────────────────────────────────────
struct Config {
    // Aim
    bool  aim_enabled   = false;
    float fov_value     = 70.0f;

    // Vehicle / Fly
    bool  fly_enabled   = false;
    float fly_speed     = 0.0f;
    float brake_force   = 0.0f;

    // Bullet track
    bool  bullet_track    = false;
    int   track_duration  = 2;
    float track_color[4]  = {1.0f, 0.0f, 0.0f, 1.0f};

    // Kill announcer
    bool  announcer     = false;
    int   kills         = 0;
    int   selected_hit  = 0;   // 0=None 1=bell 2=punch
} cfg;

// ── KILLSTREAK STATE ──────────────────────────────────────────────
inline int   kill_count     = 0;
inline long  last_kill_time = 0;

// ── BULLET TRACE ──────────────────────────────────────────────────
struct BulletTrace {
    ImVec2  start;
    ImVec2  end;
    float   die_time;
    ImColor color;
};

extern std::vector<BulletTrace> traces;

#endif // HOOKS_H
