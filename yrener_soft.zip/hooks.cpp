#include "Hooks.h"
#include "shadowhook/shadowhook.h"
#include "内存配置/include/MemoryTools.h"
#include "内存配置/include/Logger.h"
#include <sys/mman.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

std::vector<BulletTrace> traces;

// ════════════════════════════════════════════════════════════════
//   PATCH MEM
// ════════════════════════════════════════════════════════════════

void patch_mem(uintptr_t addr, void* data, size_t size) {
    uintptr_t page = addr & ~0xFFF;
    mprotect((void*)page, 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC);
    memcpy((void*)addr, data, size);
}

// ════════════════════════════════════════════════════════════════
//   SOUND ENGINE
// ════════════════════════════════════════════════════════════════

void PlayKillSound(const char* fileName) {
    char command[256];
    // Фоновый запуск — игра не фризит
    snprintf(command, sizeof(command),
        "mpv /sdcard/Download/yrener_sounds/%s --no-video --volume=100 &",
        fileName);
    system(command);
}

// ── Killstreak логика ─────────────────────────────────────────────
void OnEnemyDeath() {
    if (!cfg.announcer) return;

    long currentTime = time(NULL);

    // Сброс серии если прошло больше 15 секунд
    if (currentTime - last_kill_time > 15)
        kill_count = 0;

    kill_count++;
    last_kill_time = currentTime;
    cfg.kills = kill_count;

    switch (kill_count) {
        case 2: PlayKillSound("double.mp3");  break;  // Double Kill
        case 3: PlayKillSound("triple.mp3");  break;  // Triple Kill
        case 5: PlayKillSound("monster.mp3"); break;  // Monster Kill
        default:
            if (kill_count > 5) PlayKillSound("monster.mp3");
            break;
    }
}

// ── Хит-маркер звук ──────────────────────────────────────────────
void PlayHitSound() {
    if      (cfg.selected_hit == 1) PlayKillSound("hit_bell.mp3");
    else if (cfg.selected_hit == 2) PlayKillSound("hit_punch.mp3");
}

// ════════════════════════════════════════════════════════════════
//   BULLET IMPACT HOOK  (ADDR_BULLET_IMPACT = 0x002e6d07)
// ════════════════════════════════════════════════════════════════

// Оригинальная функция — сохраняем для вызова
static void* orig_BulletImpact = nullptr;

// Тип оригинальной функции (уточнить по дизасму если нужно)
typedef void (*tBulletImpact)(uintptr_t self, float sx, float sy, float ex, float ey);

void my_BulletImpact(uintptr_t self, float sx, float sy, float ex, float ey) {
    // Трекинг пуль
    if (cfg.bullet_track) {
        BulletTrace bt;
        bt.start    = ImVec2(sx, sy);
        bt.end      = ImVec2(ex, ey);
        bt.die_time = ImGui::GetTime() + cfg.track_duration;
        bt.color    = ImColor(
            cfg.track_color[0], cfg.track_color[1],
            cfg.track_color[2], cfg.track_color[3]);
        traces.push_back(bt);
    }

    // Звук попадания
    PlayHitSound();

    // Вызов оригинала
    if (orig_BulletImpact)
        ((tBulletImpact)orig_BulletImpact)(self, sx, sy, ex, ey);
}

// ════════════════════════════════════════════════════════════════
//   HIT EVENT HOOK  (ADDR_HIT_EVENT = 0x002ffbbd)
//   Здесь проверяем смерть и запускаем OnEnemyDeath()
// ════════════════════════════════════════════════════════════════

static void* orig_HitEvent = nullptr;

// self = указатель на RemotePlayer, damage = урон
typedef void (*tHitEvent)(uintptr_t self, float damage);

void my_HitEvent(uintptr_t self, float damage) {
    // Читаем HP цели после попадания
    // OFF_RP_HEALTH = 0x130 (из нашего анализа)
    float hp_after = 0;
    if (self) {
        memcpy(&hp_after, (void*)(self + 0x130), sizeof(float));
    }

    // Если HP <= 0 — убийство
    if (hp_after <= 0.0f) {
        OnEnemyDeath();
    }

    // Вызов оригинала
    if (orig_HitEvent)
        ((tHitEvent)orig_HitEvent)(self, damage);
}

// ════════════════════════════════════════════════════════════════
//   FOV PATCH  (ADDR_FOV = 0x00298d94)
// ════════════════════════════════════════════════════════════════

void ApplyFOV(float value) {
    uintptr_t base = getLibBase("libblackrussia-client.so");
    if (!base) return;
    patch_mem(base + ADDR_FOV, &value, sizeof(float));
}

// ════════════════════════════════════════════════════════════════
//   FLY SPEED PATCH  (ADDR_FLY_SPEED = 0x002c5153)
// ════════════════════════════════════════════════════════════════

void ApplyFlySpeed(float speed) {
    uintptr_t base = getLibBase("libblackrussia-client.so");
    if (!base) return;
    patch_mem(base + ADDR_FLY_SPEED, &speed, sizeof(float));
}

// ════════════════════════════════════════════════════════════════
//   УСТАНОВКА ВСЕХ ХУКОВ
// ════════════════════════════════════════════════════════════════

static bool g_hooks_installed = false;

void InstallHooks() {
    if (g_hooks_installed) return;

    uintptr_t base = getLibBase("libblackrussia-client.so");
    if (!base) return;

    // Хук BulletImpact через shadowhook
    orig_BulletImpact = shadowhook_hook_func_addr(
        (void*)(base + ADDR_BULLET_IMPACT),
        (void*)my_BulletImpact,
        &orig_BulletImpact
    );

    // Хук HitEvent через shadowhook
    orig_HitEvent = shadowhook_hook_func_addr(
        (void*)(base + ADDR_HIT_EVENT),
        (void*)my_HitEvent,
        &orig_HitEvent
    );

    g_hooks_installed = true;
    LOGI("[YRENER] Hooks OK. Base=0x%lx", base);
}

// ════════════════════════════════════════════════════════════════
//   ТИК — вызывать каждый кадр
// ════════════════════════════════════════════════════════════════

void HooksTick() {
    InstallHooks();

    // Применяем FOV если включён аим
    if (cfg.aim_enabled)
        ApplyFOV(cfg.fov_value);

    // Применяем скорость полёта
    if (cfg.fly_enabled)
        ApplyFlySpeed(cfg.fly_speed);

    // Чистим старые трассировки пуль
    float now = ImGui::GetTime();
    traces.erase(
        std::remove_if(traces.begin(), traces.end(),
            [now](const BulletTrace& t){ return t.die_time < now; }),
        traces.end()
    );
}

// ════════════════════════════════════════════════════════════════
//   РЕНДЕР ТРАСС ПУЛЬ (вызывать после ImGui::NewFrame)
// ════════════════════════════════════════════════════════════════

void RenderBulletTraces() {
    if (!cfg.bullet_track) return;
    auto* dl = ImGui::GetBackgroundDrawList();
    for (auto& t : traces) {
        dl->AddLine(t.start, t.end, t.color, 1.5f);
        // Точка попадания
        dl->AddCircleFilled(t.end, 3.0f, t.color);
    }
}
