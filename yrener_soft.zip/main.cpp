#include <jni.h>
#include <string>
#include <vector>
#include <time.h>
#include <algorithm>
#include <pthread.h>
#include <unistd.h>
#include <sys/mman.h>
#include <EGL/egl.h>
#include <android/native_window.h>
#include <android/configuration.h>
#include "imgui/imgui.h"
#include "imgui/backends/imgui_impl_android.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#include "shadowhook/shadowhook.h"
#include "Dobby/dobby.h"
#include "内存配置/include/MemoryTools.h"
#include "内存配置/include/Logger.h"

// ================================================================
//   YRENER SOFT — libblackrussia-client.so
// ================================================================

#define LIB_NAME        "libblackrussia-client.so"
#define ADDR_FOV         0x00298d94
#define ADDR_BULLET_IMPACT 0x002e6d07
#define ADDR_HIT_EVENT   0x002ffbbd
#define ADDR_FLY_SPEED   0x002c5153
#define OFF_RP_HEALTH    0x130       // float HP в RemotePlayer

// ================================================================
//   CONFIG
// ================================================================

struct Config {
    // Aim
    bool  aim_enabled    = false;
    float fov_value      = 70.0f;

    // Vehicle / Fly
    bool  fly_enabled    = false;
    float fly_speed      = 0.0f;
    float brake_force    = 0.0f;

    // Bullet track
    bool  bullet_track   = false;
    int   track_duration = 2;
    float track_color[4] = {1.0f, 0.0f, 0.0f, 1.0f};

    // Kill announcer
    bool  announcer      = false;
    int   kills          = 0;
    long  last_kill_time = 0;
    int   selected_hit   = 0; // 0=None 1=bell 2=punch
} cfg;

// ================================================================
//   BULLET TRACES
// ================================================================

struct BulletTrace {
    ImVec2  start;
    ImVec2  end;
    float   die_time;
    ImColor color;
};
std::vector<BulletTrace> traces;

// ================================================================
//   GLOBALS
// ================================================================

static uintptr_t g_libBase    = 0;
static bool      g_hooksOK    = false;
static bool      g_initImGui  = false;
static int       g_glW = 0, g_glH = 0;
static int       g_scrW = 0, g_scrH = 0;
static struct android_app* g_App = nullptr;

// ================================================================
//   MEMORY PATCH
// ================================================================

void patch_mem(uintptr_t addr, void* data, size_t size) {
    uintptr_t page = addr & ~0xFFF;
    mprotect((void*)page, 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC);
    memcpy((void*)addr, data, size);
}

// ================================================================
//   SOUND ENGINE
// ================================================================

void PlaySoundEffect(const char* fileName) {
    char cmd[256];
    snprintf(cmd, sizeof(cmd),
        "mpv /sdcard/Download/yrener_sounds/%s --no-video --volume=100 &",
        fileName);
    system(cmd);
}

void PlayHitSound() {
    if      (cfg.selected_hit == 1) PlaySoundEffect("hit_bell.mp3");
    else if (cfg.selected_hit == 2) PlaySoundEffect("hit_punch.mp3");
}

void OnKill() {
    if (!cfg.announcer) return;
    long now = time(NULL);

    // Сброс серии через 15 секунд
    if (now - cfg.last_kill_time > 15)
        cfg.kills = 0;

    cfg.kills++;
    cfg.last_kill_time = now;

    if      (cfg.kills == 2) PlaySoundEffect("double.mp3");
    else if (cfg.kills == 3) PlaySoundEffect("triple.mp3");
    else if (cfg.kills >= 5) PlaySoundEffect("monster.mp3");
}

// ================================================================
//   ХУКИ — CALLBACKS
// ================================================================

// ── BulletImpact ─────────────────────────────────────────────────
typedef void (*tBulletImpact)(uintptr_t self, float sx, float sy, float ex, float ey);
static tBulletImpact orig_BulletImpact = nullptr;

void my_BulletImpact(uintptr_t self, float sx, float sy, float ex, float ey) {
    if (cfg.bullet_track) {
        BulletTrace t;
        t.start    = ImVec2(sx, sy);
        t.end      = ImVec2(ex, ey);
        t.die_time = ImGui::GetTime() + cfg.track_duration;
        t.color    = ImColor(cfg.track_color[0], cfg.track_color[1],
                             cfg.track_color[2], cfg.track_color[3]);
        traces.push_back(t);
    }
    PlayHitSound();
    if (orig_BulletImpact)
        orig_BulletImpact(self, sx, sy, ex, ey);
}

// ── HitEvent (смерть) ────────────────────────────────────────────
typedef void (*tHitEvent)(uintptr_t self, float damage);
static tHitEvent orig_HitEvent = nullptr;

void my_HitEvent(uintptr_t self, float damage) {
    // Читаем HP после урона
    float hp = 0.0f;
    if (self) memcpy(&hp, (void*)(self + OFF_RP_HEALTH), sizeof(float));

    if (hp <= 0.0f) OnKill();

    if (orig_HitEvent)
        orig_HitEvent(self, damage);
}

// ── Установка хуков ──────────────────────────────────────────────
void InstallHooks() {
    if (g_hooksOK || !g_libBase) return;

    // BulletImpact
    shadowhook_hook_func_addr(
        (void*)(g_libBase + ADDR_BULLET_IMPACT),
        (void*)my_BulletImpact,
        (void**)&orig_BulletImpact
    );

    // HitEvent
    shadowhook_hook_func_addr(
        (void*)(g_libBase + ADDR_HIT_EVENT),
        (void*)my_HitEvent,
        (void**)&orig_HitEvent
    );

    g_hooksOK = true;
    LOGI("[YRENER] Hooks installed. Base=0x%lx", g_libBase);
}

// ================================================================
//   ПАТЧИ (применяются каждый кадр если включены)
// ================================================================

void ApplyPatches() {
    if (!g_libBase) return;

    if (cfg.aim_enabled)
        patch_mem(g_libBase + ADDR_FOV, &cfg.fov_value, sizeof(float));

    if (cfg.fly_enabled)
        patch_mem(g_libBase + ADDR_FLY_SPEED, &cfg.fly_speed, sizeof(float));
}

// ================================================================
//   МЕНЮ
// ================================================================

void RenderYrenerMenu() {
    ImGui::Begin("YRENER SOFT [MOBILE]");

    // ── AIM ──────────────────────────────────────────────────────
    if (ImGui::CollapsingHeader("AIM")) {
        ImGui::Checkbox("Aimbot", &cfg.aim_enabled);
        ImGui::TextColored(ImVec4(1,0,0,1), "WARNING 10 SECONDS");
        ImGui::SliderFloat("FOV", &cfg.fov_value, 70.0f, 180.0f);
    }

    // ── VEHICLE ──────────────────────────────────────────────────
    if (ImGui::CollapsingHeader("VEHICLE")) {
        ImGui::Checkbox("Enable Fly",   &cfg.fly_enabled);
        ImGui::SliderFloat("Speed",     &cfg.fly_speed,   0.0f, 100.0f);
        ImGui::SliderFloat("Brake",     &cfg.brake_force, 0.0f, 1.0f);
    }

    // ── MISC ─────────────────────────────────────────────────────
    if (ImGui::CollapsingHeader("MISC")) {

        ImGui::Checkbox("Bullet Track", &cfg.bullet_track);
        ImGui::SameLine();
        if (ImGui::Button("Gear")) ImGui::OpenPopup("TrackCfg");

        if (ImGui::BeginPopup("TrackCfg")) {
            ImGui::Text("Duration & Color");
            ImGui::SliderInt("Time (s)",  &cfg.track_duration, 2, 9);
            ImGui::ColorEdit4("Color",    cfg.track_color);
            ImGui::EndPopup();
        }

        ImGui::Separator();

        const char* hits[] = { "None", "Notification 1", "Notification 2" };
        ImGui::Combo("Hit Sound", &cfg.selected_hit, hits, 3);

        if (ImGui::TreeNode("Sound Mix (Legendary)")) {
            ImGui::Checkbox("Enable Kill Announcer", &cfg.announcer);
            if (cfg.announcer) {
                ImGui::Text("Current Streak: %d", cfg.kills);
                if (ImGui::Button("Test Monster Kill")) OnKill();
                if (ImGui::Button("Reset streak")) {
                    cfg.kills = 0;
                }
            }
            ImGui::TreePop();
        }
    }

    // ── DEBUG ─────────────────────────────────────────────────────
    if (ImGui::CollapsingHeader("DEBUG")) {
        ImGui::Text("Base: 0x%lx", g_libBase);
        ImGui::Text("Hooks: %s", g_hooksOK ? "OK" : "...");
        ImGui::Text("Traces: %d", (int)traces.size());
    }

    ImGui::End();

    // ── Рендер следов пуль ───────────────────────────────────────
    float curTime = ImGui::GetTime();
    traces.erase(
        std::remove_if(traces.begin(), traces.end(),
            [curTime](const BulletTrace& t){ return t.die_time < curTime; }),
        traces.end()
    );
    for (auto& t : traces) {
        ImGui::GetBackgroundDrawList()->AddLine(t.start, t.end, t.color, 2.0f);
        ImGui::GetBackgroundDrawList()->AddCircleFilled(t.end, 3.0f, t.color);
    }
}

// ================================================================
//   EGL SWAP BUFFERS
// ================================================================

EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay, EGLSurface);
EGLBoolean my_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH,  &g_glW);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &g_glH);
    if (g_glW <= 0 || g_glH <= 0 || !g_App)
        return orig_eglSwapBuffers(dpy, surface);

    g_scrW = ANativeWindow_getWidth(g_App->window);
    g_scrH = ANativeWindow_getHeight(g_App->window);

    if (!g_initImGui) {
        ImGui::CreateContext();
        ImGuiStyle* style = &ImGui::GetStyle();
        ImGui::StyleColorsDark(style);
        style->WindowRounding  = 5.0f;
        style->FrameRounding   = 3.0f;
        style->GrabMinSize     = 13.0f;
        style->WindowMinSize   = ImVec2(150, 20);
        ImGui_ImplAndroid_Init();
        ImGui_ImplOpenGL3_Init("#version 300 es");
        ImGui::GetIO().IniFilename = NULL;
        g_initImGui = true;
    }

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(g_glW, g_glH);
    ImGui::NewFrame();

    InstallHooks();
    ApplyPatches();
    RenderYrenerMenu();

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    return orig_eglSwapBuffers(dpy, surface);
}

// ================================================================
//   INPUT
// ================================================================

int32_t (*orig_onInputEvent)(struct android_app*, AInputEvent*);
int32_t my_onInputEvent(struct android_app* app, AInputEvent* ev) {
    if (g_initImGui)
        ImGui_ImplAndroid_HandleInputEvent(ev,
            {(float)g_scrW/(float)g_glW, (float)g_scrH/(float)g_glH});
    return orig_onInputEvent(app, ev);
}

// ================================================================
//   MAIN THREAD
// ================================================================

void* main_thread(void*) {
    // Ждём загрузки либы
    while (!g_libBase) {
        g_libBase = getLibBase(LIB_NAME);
        sleep(1);
    }
    LOGI("[YRENER] Base: 0x%lx", g_libBase);

    // Ждём g_App
    while (!g_App) sleep(1);

    orig_onInputEvent       = g_App->onInputEvent;
    g_App->onInputEvent     = my_onInputEvent;

    void* egl  = dlopen("libEGL.so", RTLD_NOW);
    void* addr = dlsym(egl, "eglSwapBuffers");
    DobbyHook(addr, (void*)my_eglSwapBuffers, (void**)&orig_eglSwapBuffers);

    return nullptr;
}

// ================================================================
//   ENTRY POINT
// ================================================================

__attribute__((constructor)) void _init() {
    pthread_t t;
    pthread_create(&t, nullptr, main_thread, nullptr);
}
